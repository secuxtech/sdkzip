//
//  secux_paymentdevicekit.h
//  secux-paymentdevicekit
//
//  Created by Maochun Sun on 2020/4/23.
//  Copyright © 2020 SecuX. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for secux_paymentdevicekit.
FOUNDATION_EXPORT double secux_paymentdevicekitVersionNumber;

//! Project version string for secux_paymentdevicekit.
FOUNDATION_EXPORT const unsigned char secux_paymentdevicekitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <secux_paymentdevicekit/PublicHeader.h>


